# Dublin BTL Analyst Skill v7 -- Install Script
# Run from PowerShell as Administrator

$SkillDir = "$env:APPDATA\Claude\local-agent-mode-sessions\skills-plugin"
$SkillName = "dublin-rental-property-analyst"

# Find the skill directory (search under skills-plugin subdirs)
$TargetDirs = Get-ChildItem -Path $SkillDir -Recurse -Filter "SKILL.md" |
    Where-Object { $_.DirectoryName -match $SkillName } |
    Select-Object -ExpandProperty DirectoryName

if (-not $TargetDirs) {
    Write-Error "Could not find existing skill directory. Install the skill manually."
    exit 1
}

$TargetDir = $TargetDirs[0]
Write-Host "Installing to: $TargetDir"

# Copy SKILL.md
Copy-Item "$PSScriptRoot\SKILL.md" "$TargetDir\SKILL.md" -Force

# Copy all reference files
$RefSrc = "$PSScriptRoot\references"
$RefDst = "$TargetDir\references"
New-Item -ItemType Directory -Force -Path $RefDst | Out-Null
Get-ChildItem "$RefSrc\*.md" | ForEach-Object {
    Copy-Item $_.FullName "$RefDst\$($_.Name)" -Force
    Write-Host "  Copied: $($_.Name)"
}

Write-Host "v7 skill installed successfully. Restart Claude to pick up the new version."
